# 🚀 Vercel Deployment Guide for HydraLearn

## Prerequisites

Before deploying, ensure you have:
1. A [Vercel account](https://vercel.com/signup)
2. A [Google AI API Key](https://aistudio.google.com/app/apikey) for Gemini
3. A PostgreSQL database (options below)

---

## Step 1: Database Setup

HydraLearn requires a PostgreSQL database for production. Choose one:

### Option A: Vercel Postgres (Recommended)
1. Go to your Vercel Dashboard → Storage
2. Click "Create Database" → Select "Postgres"
3. Copy the connection strings

### Option B: Neon (Free Tier Available)
1. Sign up at [neon.tech](https://neon.tech)
2. Create a new project
3. Copy the connection string from the dashboard

### Option C: Supabase
1. Sign up at [supabase.com](https://supabase.com)
2. Create a new project
3. Go to Settings → Database → Connection string

---

## Step 2: Deploy to Vercel

### Method 1: One-Click Deploy (Easiest)

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/C-Jay69/HYDRALEARN_GLM4.7_JAN22)

### Method 2: Via Vercel CLI

```bash
# Install Vercel CLI
npm i -g vercel

# Login to Vercel
vercel login

# Deploy from project root
vercel
```

### Method 3: Via GitHub Integration

1. Push your code to GitHub
2. Go to [vercel.com/new](https://vercel.com/new)
3. Import your repository
4. Configure environment variables (Step 3)
5. Click "Deploy"

---

## Step 3: Configure Environment Variables

In your Vercel project dashboard, go to **Settings → Environment Variables** and add:

| Variable | Required | Description |
|----------|----------|-------------|
| `GEMINI_API_KEY` | ✅ Yes | Your Google AI API key |
| `DATABASE_URL` | ✅ Yes | PostgreSQL connection string (pooled) |
| `DIRECT_URL` | ✅ Yes | PostgreSQL direct connection string |
| `NEXTAUTH_SECRET` | ✅ Yes | Run `openssl rand -base64 32` to generate |
| `NEXTAUTH_URL` | ✅ Yes | Your production URL (e.g., https://your-app.vercel.app) |

### Example Values:
```
GEMINI_API_KEY=AIzaSy...your-key
DATABASE_URL=postgres://user:pass@host/db?sslmode=require&pgbouncer=true
DIRECT_URL=postgres://user:pass@host/db?sslmode=require
NEXTAUTH_SECRET=your-generated-secret
NEXTAUTH_URL=https://hydralearn.vercel.app
```

---

## Step 4: Initialize Database

After first deployment, run database migrations:

```bash
# Using Vercel CLI
vercel env pull .env.local
npx prisma db push
```

Or via Vercel's Functions tab, trigger the database setup.

---

## Step 5: Verify Deployment

1. Visit your deployed URL
2. Test the AI features (Lesson Planner, Essay Grader, etc.)
3. Check Vercel logs if any issues occur

---

## Troubleshooting

### "API key missing" error
- Ensure `GEMINI_API_KEY` is set in Vercel Environment Variables
- Redeploy after adding the variable

### Database connection errors
- Verify `DATABASE_URL` and `DIRECT_URL` are correct
- Ensure your database allows connections from Vercel's IPs
- For Neon/Supabase: Enable "Pooled connection" mode

### Build failures
- Check Vercel build logs for specific errors
- Ensure all dependencies are in `package.json`
- Node version should be >= 18

### AI features not working
- Verify your Gemini API key is valid
- Check API quota at [Google AI Studio](https://aistudio.google.com)
- Review function logs in Vercel dashboard

---

## Environment Variables Reference

```bash
# Required
GEMINI_API_KEY=           # Google AI API key
DATABASE_URL=             # PostgreSQL pooled connection
DIRECT_URL=               # PostgreSQL direct connection
NEXTAUTH_SECRET=          # Auth encryption key
NEXTAUTH_URL=             # Your production URL

# Optional
GOOGLE_GENAI_API_KEY=     # Alternative to GEMINI_API_KEY
```

---

## Post-Deployment Checklist

- [ ] All AI features working (Lesson Planner, Essay Grader, etc.)
- [ ] Database connected and accessible
- [ ] Custom domain configured (optional)
- [ ] SSL certificate active
- [ ] Analytics enabled (optional)

---

## Support

For issues specific to:
- **Vercel**: [vercel.com/docs](https://vercel.com/docs)
- **Prisma**: [prisma.io/docs](https://www.prisma.io/docs)
- **Google AI**: [ai.google.dev](https://ai.google.dev)

---

Happy deploying! 🎉
