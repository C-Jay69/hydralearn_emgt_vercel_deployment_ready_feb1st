import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Build configuration
  typescript: {
    ignoreBuildErrors: true,
  },
  eslint: {
    ignoreDuringBuilds: true,
  },
  
  // External packages for AI integration
  transpilePackages: ['@genkit-ai', '@google/generative-ai'],
  
  // Vercel-optimized settings
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: '**',
      },
    ],
  },
  
  // Serverless function configuration
  experimental: {
    serverComponentsExternalPackages: ['sharp', 'prisma', '@prisma/client'],
  },
};

export default nextConfig;